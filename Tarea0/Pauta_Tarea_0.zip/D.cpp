#include <bits/stdc++.h>
using namespace std;

int main(){
	// Cada persona con altura <= h contribuye 1 a la respuesta,
	// cada persona con altura > h contribuye 2.
	int n, h;
	cin >> n >> h;

	vector <int> a(n); // Vector "a" de tamaño n

	for(int i=0; i<n; i++){ // Leemos los n números y guardamos en el vector
		cin >> a[i];
	}

	int res = 0; // La respuesta

	for(int i=0; i<n; i++){
		if(a[i] > h){ // Si la i-ésima persona es muy alta, sumamos 2 porque se tiene que agachar
			res += 2;
		}
		else{ // Si no, sumamos 1
			res++;
		}
	}
	// En verdad podríamos haber omitido el vector, ya que podríamos haber leído los números al mismo
	// tiempo que calculábamos la respuesta (no es necesario guardarlos), pero es buena idea practicar vector.
	cout << res << '\n';
	return 0;
}
