#include <iostream>
using namespace std;

int main(){
	int w;
	cin >> w;

	// Idea: si w es par, podemos separarla en (w-2)+(2).
	// Caso borde: si w==2, w-2 es cero y el problema no lo permite.
	// Solución: ver que w sea par y mayor que 2
	
	if(w%2 == 0 and w>2){
		cout << "YES\n"; // Es buena práctica poner saltos de línea al final
	}
	else{
		cout << "NO\n";
	}
	return 0;
}
