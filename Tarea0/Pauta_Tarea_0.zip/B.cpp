#include <iostream>
#include <string> // Usamos strings
using namespace std;

void solve(){
	// Función que resuelve un caso de prueba
	string palabra;
	cin >> palabra;
	
	if(palabra.size() > 10){
		cout << palabra[0] << palabra.size()-2 << palabra.back() << '\n';
		// Pro tip: en vez de hacer
		// palabra[palabra.size()-1]
		// para obtener el último, el método .back() entrega el último
		// y es más legible (también funciona en vectores)
		// De la misma forma, palabra.front() entrega el primero
	}
	else{
		cout << palabra << '\n';
	}
}

int main(){
	// Esto puede ser un poco confuso, pero cada caso de prueba tiene
	// n casos de prueba en él. Esto lo hacen algunos jueces para 
	// evitar correr muchas veces su programa (y así revisar más rápido)
	int n;
	cin >> n;
	for(int i=0; i<n; i++){
		// Llamamos a una función que resuelve
		// cada caso por separado
		solve();
	}
	return 0;
}
