#include <iostream>
using namespace std;

int main(){
	// Como son solo ceros y un uno, intercambiar dos filas o columnas adyacentes
	// es equivalente a mover el 1 una posición en alguna dirección (arriba,
	// abajo, izquierda, derecha). Por lo tanto, lo que queremos encontrar es 
	// la distancia del 1 hasta el centro.

	int matriz[5][5]; // Podríamos usar un vector de vectores, pero aún no vemos vector
	// (y la sintaxis para hacer vector de vectores es más fea)
	
	int x, y; // Las coordenadas (x,y) serán la posición del 1

	for(int i=0; i<5; i++){
		for(int j=0; j<5; j++){
			cin >> matriz[i][j]; // Usamos un doble for para leer cada número de la matriz
			if(matriz[i][j] == 1){ // Si leímos un 1, guardamos sus coordenadas
				x = i;
				y = j;
			}
		}
	}

	// La respuesta será la distancia de "x" al 2 más la distancia de "y" al 2
	// que significa cuánto debo moverlo horizontalmente, más cuánto debo moverlo verticalmente
	// para llegar al centro.
	// abs() calcula el valor absoluto de su argumento.
	int res = abs(2-x) + abs(2-y);
	cout << res << '\n';
	return 0;
}
